# LANraragi Documentation

_I know when to go out_  
_Know when to stay in_  
_Get things done_

Thank you for showing interest in this networked chinese comic reading software.

Just getting started? Check out how to install the software:

{% page-ref page="installing-lanraragi/methods.md" %}

Or how to use your freshly installed instance:

{% page-ref page="basic-operations/first-steps.md" %}

